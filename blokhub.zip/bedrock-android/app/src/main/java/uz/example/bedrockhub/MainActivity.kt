package uz.example.bedrockhub

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

private const val BEDROCK_PKG = "com.mojang.minecraftpe"
private const val CF_GAME_ID = 78022 // CurseForge: Minecraft Bedrock
private const val REQ_PICK = 1001
private val BEDROCK_EXT = listOf(".mcpack", ".mcaddon", ".mcworld", ".mctemplate")
private val VERSIONS = listOf("1.21", "1.20", "1.19", "1.18", "1.17", "1.16") // "" = hammasi
private val LANG_CODES = listOf("uz", "ru", "en")

private const val BG = 0xFF090909.toInt()
private const val PANEL = 0xFF141414.toInt()
private const val GREEN = 0xFF22C55E.toInt()
private const val MUTED = 0xFF9CA3AF.toInt()

private var lastTab = "home"

private data class Item(
    val id: Int,
    val name: String,
    val summary: String,
    val versions: String,
    val downloads: Long,
    val fileId: Int?,
    val url: String
)

class MainActivity : Activity() {

    private lateinit var content: LinearLayout
    private val tabs = linkedMapOf<String, View>()
    private lateinit var homeMsg: TextView
    private lateinit var filesMsg: TextView
    private lateinit var setMsg: TextView
    private lateinit var mineList: LinearLayout
    private lateinit var hasanList: LinearLayout
    private lateinit var hasanMsg: TextView
    private var classes: List<Pair<Int, String>>? = null

    private fun prefs() = getSharedPreferences("s", MODE_PRIVATE)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun vbox(pad: Int = 16) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG

        // Til: saqlangan, bo'lmasa telefon tili (ru/en), aks holda o'zbekcha
        val saved = prefs().getString("lang", null) ?: Locale.getDefault().language
        langIdx = when (saved) { "ru" -> 1; "en" -> 2; else -> 0 }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        tabs["home"] = buildHome()
        tabs["hasan"] = buildHasan()
        tabs["mods"] = Catalog("mods").view
        tabs["maps"] = Catalog("maps").view
        tabs["tex"] = Catalog("textures").view
        tabs["mine"] = buildFiles()
        tabs["guide"] = buildGuide()
        tabs["settings"] = buildSettings()

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (key in tabs.keys) bar.addView(button(t("tab_$key")) { showTab(key) })
        root.addView(HorizontalScrollView(this).apply { addView(bar) })
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        showTab(if (tabs.containsKey(lastTab)) lastTab else "home")
    }

    private fun showTab(key: String) {
        lastTab = key
        content.removeAllViews()
        content.addView(tabs[key], LinearLayout.LayoutParams(-1, -1))
        if (key == "hasan") loadHasan()
    }

    // ---------- Bosh ----------
    private fun buildHome(): View {
        val box = vbox(24)
        box.addView(label("BlokHub", 28f, GREEN, true))
        box.addView(label(t("home_sub"), 14f, MUTED))
        val play = button(t("play")) { launchGame() }
        play.setBackgroundColor(GREEN)
        play.setTextColor(0xFF052E16.toInt())
        play.textSize = 20f
        box.addView(play, LinearLayout.LayoutParams(-1, dp(64)).apply { topMargin = dp(24) })
        homeMsg = label("", 13f, MUTED)
        box.addView(homeMsg)
        box.addView(label(t("unofficial"), 11f, MUTED).apply { setPadding(0, dp(32), 0, 0) })
        return box
    }

    private fun launchGame() {
        val i = packageManager.getLaunchIntentForPackage(BEDROCK_PKG)
        if (i == null) {
            homeMsg.text = t("play_missing")
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$BEDROCK_PKG")))
            } catch (_: ActivityNotFoundException) { }
        } else {
            startActivity(i)
        }
    }

    // ---------- Katalog (Modlar / Xaritalar / Teksturalar) ----------
    private inner class Catalog(private val kind: String) {
        val view: View
        private val msg: TextView
        private val list: LinearLayout
        private val query: EditText
        private val verBtn: Button
        private var version = "" // "" = hammasi

        init {
            val box = vbox()
            val title = when (kind) {
                "mods" -> t("title_mods")
                "maps" -> t("title_maps")
                else -> t("title_tex")
            }
            box.addView(label(title, 20f, bold = true))
            query = EditText(this@MainActivity).apply {
                hint = t("search_hint"); setTextColor(Color.WHITE); setHintTextColor(MUTED); isSingleLine = true
            }
            box.addView(query)
            val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            verBtn = button(tf("version_btn", t("all"))) {}
            verBtn.setOnClickListener {
                val names = (listOf(t("all")) + VERSIONS).toTypedArray()
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(t("version_dialog"))
                    .setItems(names) { _, i ->
                        version = if (i == 0) "" else VERSIONS[i - 1]
                        verBtn.text = tf("version_btn", names[i])
                        search()
                    }.show()
            }
            row.addView(verBtn)
            row.addView(button(t("search_btn")) { search() })
            box.addView(row)
            msg = label("", 13f, MUTED)
            box.addView(msg)
            list = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            box.addView(ScrollView(this@MainActivity).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
            view = box
        }

        fun search() {
            val key = apiKey()
            if (key.isBlank()) { msg.text = t("no_key"); return }
            msg.text = t("searching")
            list.removeAllViews()
            val q = query.text.toString()
            val ver = version
            Thread {
                try {
                    val sb = StringBuilder("https://api.curseforge.com/v1/mods/search?gameId=$CF_GAME_ID" +
                        "&sortField=2&sortOrder=desc&pageSize=50")
                    if (q.isNotBlank()) sb.append("&searchFilter=").append(URLEncoder.encode(q, "UTF-8"))
                    val classId = classIdFor(kind, key)
                    if (classId != null) sb.append("&classId=").append(classId)
                    val arr = JSONObject(httpGet(sb.toString(), key)).getJSONArray("data")
                    val items = mutableListOf<Item>()
                    for (n in 0 until arr.length()) {
                        val m = arr.getJSONObject(n)
                        val versions = linkedMapOf<String, Int>() // o'yin versiyasi -> fileId
                        val idx = m.optJSONArray("latestFilesIndexes")
                        if (idx != null) {
                            for (k in 0 until idx.length()) {
                                val o = idx.getJSONObject(k)
                                val gv = o.optString("gameVersion")
                                if (gv.isNotBlank() && !versions.containsKey(gv)) versions[gv] = o.getInt("fileId")
                            }
                        }
                        var fileId: Int? = versions.values.firstOrNull()
                        if (ver.isNotEmpty()) {
                            val hit = versions.entries.firstOrNull { it.key == ver || it.key.startsWith("$ver.") }
                                ?: continue
                            fileId = hit.value
                        }
                        items.add(Item(
                            m.getInt("id"), m.getString("name"), m.optString("summary"),
                            versions.keys.take(4).joinToString(", "), m.optLong("downloadCount"),
                            fileId, m.optJSONObject("links")?.optString("websiteUrl") ?: ""
                        ))
                    }
                    runOnUiThread {
                        msg.text = if (items.isEmpty()) t("none_found") else tf("n_results", items.size)
                        for (item in items) list.addView(card(item))
                    }
                } catch (e: Exception) {
                    runOnUiThread { msg.text = tf("err", e.message ?: "") }
                }
            }.start()
        }

        private fun card(item: Item): View {
            val c = vbox(12).apply {
                setBackgroundColor(PANEL)
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
            }
            c.addView(label(item.name, 16f, bold = true))
            c.addView(label(item.summary, 12f, MUTED))
            if (item.versions.isNotBlank()) c.addView(label(tf("versions_lbl", item.versions), 12f, GREEN))
            c.addView(label(tf("downloads_lbl", item.downloads), 11f, MUTED))
            val b = button(t("install_btn")) {}
            b.setOnClickListener {
                b.isEnabled = false; b.text = t("loading_btn")
                install(item) { text ->
                    runOnUiThread { msg.text = text; b.isEnabled = true; b.text = t("install_btn") }
                }
            }
            c.addView(b)
            return c
        }
    }

    private fun classIdFor(kind: String, key: String): Int? {
        if (classes == null) {
            val arr = JSONObject(httpGet(
                "https://api.curseforge.com/v1/categories?gameId=$CF_GAME_ID&classesOnly=true", key
            )).getJSONArray("data")
            classes = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                o.getInt("id") to (o.optString("slug") + " " + o.optString("name")).lowercase()
            }
        }
        val words = when (kind) {
            "mods" -> listOf("addon", "add-on", "mod")
            "maps" -> listOf("map", "world")
            else -> listOf("texture", "resource")
        }
        for (w in words) {
            val hit = classes!!.firstOrNull { it.second.contains(w) }
            if (hit != null) return hit.first
        }
        return null
    }

    private fun install(item: Item, done: (String) -> Unit) {
        val key = apiKey()
        Thread {
            try {
                val file: JSONObject? = if (item.fileId != null) {
                    JSONObject(httpGet("https://api.curseforge.com/v1/mods/${item.id}/files/${item.fileId}", key))
                        .optJSONObject("data")
                } else {
                    JSONObject(httpGet("https://api.curseforge.com/v1/mods/${item.id}/files?pageSize=1", key))
                        .getJSONArray("data").optJSONObject(0)
                }
                if (file == null) { done(t("file_missing")); return@Thread }
                val url = file.optString("downloadUrl")
                if (url.isBlank() || url == "null") {
                    runOnUiThread { openBrowser(item.url) }
                    done(t("ext_disabled"))
                    return@Thread
                }
                val safe = File(file.getString("fileName")).name.replace(Regex("[^\\w.\\- ]"), "_")
                val dir = File(cacheDir, "downloads").apply { mkdirs() }
                val dest = File(dir, safe)
                download(url, dest)
                if (BEDROCK_EXT.none { safe.lowercase().endsWith(it) }) {
                    runOnUiThread { openBrowser(item.url) }
                    done(tf("not_bedrock", safe))
                    return@Thread
                }
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", dest)
                runOnUiThread { openInMinecraft(uri) }
                done(tf("sent", safe))
            } catch (e: Exception) {
                done(tf("err", e.message ?: ""))
            }
        }.start()
    }

    // ---------- Qo'llanma ----------
    private fun buildGuide(): View {
        val box = vbox(20)
        box.addView(label(t("g_title"), 22f, bold = true))
        for (n in 1..6) {
            box.addView(label(t("g_h$n"), 18f, GREEN, true).apply { setPadding(0, dp(16), 0, dp(4)) })
            box.addView(label(t("g_p$n"), 14f, Color.WHITE))
        }
        return ScrollView(this).apply { addView(box) }
    }

    // ---------- Mening modlarim ----------
    private fun buildFiles(): View {
        val box = vbox(24)
        box.addView(label(t("mine_title"), 22f, bold = true))
        box.addView(label(t("mine_desc"), 14f, MUTED))
        box.addView(button(t("pick_btn")) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivityForResult(i, REQ_PICK)
        })
        filesMsg = label("", 13f, MUTED)
        box.addView(filesMsg)
        mineList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(ScrollView(this).apply { addView(mineList) }, LinearLayout.LayoutParams(-1, 0, 1f))
        refreshMine()
        return box
    }

    private fun mineEntries(): List<Pair<String, String>> {
        val set = prefs().getStringSet("mine", emptySet()) ?: emptySet()
        return set.mapNotNull {
            val i = it.indexOf('|')
            if (i < 0) null else it.substring(0, i) to it.substring(i + 1)
        }.sortedBy { it.second.lowercase() }
    }

    private fun saveMine(entries: List<Pair<String, String>>) {
        prefs().edit().putStringSet("mine", entries.map { it.first + "|" + it.second }.toSet()).apply()
    }

    private fun displayName(u: Uri): String {
        try {
            contentResolver.query(u, null, null, null, null)?.use { c ->
                val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (col >= 0 && c.moveToFirst()) return c.getString(col)
            }
        } catch (_: Exception) { }
        return u.lastPathSegment ?: "file"
    }

    private fun refreshMine() {
        mineList.removeAllViews()
        val entries = mineEntries()
        if (entries.isEmpty()) { mineList.addView(label(t("mine_empty"), 13f, MUTED)); return }
        for ((uri, name) in entries) {
            val row = vbox(12).apply {
                setBackgroundColor(PANEL)
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
            }
            row.addView(label(name, 15f, bold = true))
            val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            btns.addView(button(t("send_btn")) {
                try { openInMinecraft(Uri.parse(uri)) }
                catch (_: Exception) { filesMsg.text = t("open_fail") }
            })
            btns.addView(button(t("delete_btn")) {
                saveMine(mineEntries().filter { it.first != uri })
                refreshMine()
            })
            row.addView(btns)
            mineList.addView(row)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK && data != null) {
            val uris = mutableListOf<Uri>()
            data.data?.let { uris.add(it) }
            val cd = data.clipData
            if (cd != null) for (n in 0 until cd.itemCount) uris.add(cd.getItemAt(n).uri)
            val entries = mineEntries().toMutableList()
            for (u in uris.distinct()) {
                try {
                    contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) { }
                if (entries.none { it.first == u.toString() }) entries.add(u.toString() to displayName(u))
            }
            saveMine(entries)
            filesMsg.text = tf("added", uris.distinct().size)
            refreshMine()
        }
    }

    // ---------- HasanMC modlari (muallifning o'z katalogi) ----------
    private fun hasanUrl() = prefs().getString("hasanUrl", "") ?: ""

    private fun buildHasan(): View {
        val box = vbox()
        box.addView(label(t("hasan_title"), 20f, GREEN, true))
        box.addView(label(t("hasan_sub"), 13f, MUTED))
        box.addView(button(t("refresh")) { loadHasan() })
        hasanMsg = label("", 13f, MUTED)
        box.addView(hasanMsg)
        hasanList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(ScrollView(this).apply { addView(hasanList) }, LinearLayout.LayoutParams(-1, 0, 1f))
        return box
    }

    private fun loadHasan() {
        val url = hasanUrl()
        if (!url.startsWith("https://")) { hasanMsg.text = t("need_url"); return }
        hasanMsg.text = t("loading")
        hasanList.removeAllViews()
        Thread {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 20000
                if (c.responseCode != 200) throw RuntimeException(tf("cat_missing", c.responseCode))
                val text = c.inputStream.bufferedReader().use { it.readText() }.trim()
                val arr = if (text.startsWith("[")) JSONArray(text) else JSONObject(text).getJSONArray("mods")
                runOnUiThread {
                    hasanMsg.text = if (arr.length() == 0) t("no_mods_yet") else tf("n_mods", arr.length())
                    for (n in 0 until arr.length()) hasanList.addView(hasanCard(arr.getJSONObject(n)))
                }
            } catch (e: Exception) {
                runOnUiThread { hasanMsg.text = tf("err", e.message ?: "") }
            }
        }.start()
    }

    private fun hasanCard(m: JSONObject): View {
        val name = m.optString("name", t("nameless"))
        val url = m.optString("url")
        val c = vbox(12).apply {
            setBackgroundColor(PANEL)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        }
        c.addView(label(name, 16f, bold = true))
        val desc = m.optString("description")
        if (desc.isNotBlank()) c.addView(label(desc, 12f, MUTED))
        val meta = listOf(m.optString("version"), m.optString("mcVersion")).filter { it.isNotBlank() }
        if (meta.isNotEmpty()) c.addView(label(meta.joinToString("  •  "), 12f, GREEN))
        val b = button(t("install_btn")) {}
        b.setOnClickListener {
            b.isEnabled = false; b.text = t("loading_btn")
            val fileName = m.optString("file").ifBlank { url.substringBefore('?').substringAfterLast('/') }
            installDirect(url, fileName) { text ->
                runOnUiThread { hasanMsg.text = text; b.isEnabled = true; b.text = t("install_btn") }
            }
        }
        c.addView(b)
        return c
    }

    private fun installDirect(url: String, fileName: String, done: (String) -> Unit) {
        Thread {
            try {
                if (!url.startsWith("https://")) { done(t("https_needed")); return@Thread }
                val safe = File(fileName).name.replace(Regex("[^\\w.\\- ]"), "_")
                if (BEDROCK_EXT.none { safe.lowercase().endsWith(it) }) { done(t("bad_type")); return@Thread }
                val dir = File(cacheDir, "downloads").apply { mkdirs() }
                val dest = File(dir, safe)
                download(url, dest)
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", dest)
                runOnUiThread { openInMinecraft(uri) }
                done(tf("sent", safe))
            } catch (e: Exception) {
                done(tf("err", e.message ?: ""))
            }
        }.start()
    }

    // ---------- Sozlamalar ----------
    private fun apiKey() = prefs().getString("cfKey", "") ?: ""

    private fun setLang(code: String) {
        prefs().edit().putString("lang", code).apply()
        lastTab = "settings"
        recreate()
    }

    private fun buildSettings(): View {
        val box = vbox(24)
        box.addView(label(t("set_title"), 22f, bold = true))

        box.addView(label(t("lang_label"), 14f, MUTED).apply { setPadding(0, dp(8), 0, 0) })
        val langRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("O'zbekcha", "Русский", "English")
        for (i in names.indices) {
            val b = button(names[i]) { setLang(LANG_CODES[i]) }
            if (i == langIdx) { b.setBackgroundColor(GREEN); b.setTextColor(0xFF052E16.toInt()) }
            langRow.addView(b)
        }
        box.addView(langRow)

        box.addView(label(t("cf_label"), 13f, MUTED).apply { setPadding(0, dp(16), 0, 0) })
        val et = EditText(this).apply {
            setTextColor(Color.WHITE); isSingleLine = true; setText(apiKey())
        }
        box.addView(et)
        box.addView(label(t("hasan_label"), 13f, MUTED).apply { setPadding(0, dp(16), 0, 0) })
        val hu = EditText(this).apply {
            setTextColor(Color.WHITE); isSingleLine = true; setText(hasanUrl())
        }
        box.addView(hu)
        setMsg = label("", 13f, MUTED)
        box.addView(button(t("save_btn")) {
            prefs().edit()
                .putString("cfKey", et.text.toString().trim())
                .putString("hasanUrl", hu.text.toString().trim())
                .apply()
            setMsg.text = t("saved")
        })
        box.addView(setMsg)
        return ScrollView(this).apply { addView(box) }
    }

    // ---------- Yordamchi ----------
    private fun openBrowser(url: String) {
        if (url.isBlank()) return
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: ActivityNotFoundException) { }
    }

    private fun openInMinecraft(uri: Uri) {
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent(i).setPackage(BEDROCK_PKG))
        } catch (_: ActivityNotFoundException) {
            try { startActivity(Intent.createChooser(i, "Minecraft")) }
            catch (_: ActivityNotFoundException) { }
        }
    }

    private fun httpGet(url: String, key: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("Accept", "application/json")
        c.connectTimeout = 15000; c.readTimeout = 20000
        if (c.responseCode != 200) throw RuntimeException("CurseForge ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun download(url: String, dest: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        c.instanceFollowRedirects = true
        if (c.responseCode != 200) throw RuntimeException("HTTP ${c.responseCode}")
        c.inputStream.use { inp -> dest.outputStream().use { out -> inp.copyTo(out) } }
    }
}
