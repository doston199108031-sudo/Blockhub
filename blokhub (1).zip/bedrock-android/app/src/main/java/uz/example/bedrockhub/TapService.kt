package uz.example.bedrockhub

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast

/**
 * O'yin ustida suzuvchi tugmalar. Tugma bosilganda ekranning belgilangan nuqtasiga tegib qo'yadi.
 * Haqiqiy klaviatura tugmalarini (Q, F5, F1) Android'da bosib bo'lmaydi, shuning uchun
 * har bir tugma o'yin ekranidagi tanlangan joyga bosadi.
 */
class TapService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: TapService? = null
    }

    private lateinit var wm: WindowManager
    private val btnViews = HashMap<String, View>()
    private val markViews = HashMap<String, View>()
    private var handle: TextView? = null
    private var cfgs: MutableList<Cfg> = mutableListOf()
    private var inGame = false
    private var editing = false
    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        clear()
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg.contains("systemui") || pkg.contains("inputmethod") || pkg.contains("keyboard")) return
        if (GAME_PKGS.contains(pkg)) {
            if (!inGame) {
                inGame = true
                rebuild()
            }
        } else if (inGame) {
            inGame = false
            editing = false
            clear()
        }
    }

    fun refresh() {
        if (inGame) rebuild()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun params(w: Int, h: Int, x: Int, y: Int): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = x
        p.y = y
        return p
    }

    private fun circle(label: String, sizePx: Int, fill: Int, stroke: Int, textSp: Float): TextView {
        val t = TextView(this)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        t.textSize = textSp
        t.typeface = Typeface.DEFAULT_BOLD
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(fill)
        bg.setStroke(dp(2), stroke)
        t.background = bg
        t.width = sizePx
        t.height = sizePx
        return t
    }

    private fun clear() {
        if (!::wm.isInitialized) return
        for (v in btnViews.values) try { wm.removeView(v) } catch (_: Exception) { }
        for (v in markViews.values) try { wm.removeView(v) } catch (_: Exception) { }
        handle?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        btnViews.clear()
        markViews.clear()
        handle = null
    }

    private fun rebuild() {
        clear()
        if (!inGame || !::wm.isInitialized) return
        cfgs = Store.load(this)
        for (c in cfgs) if (c.enabled) addButton(c)
        if (editing) for (c in cfgs) if (c.enabled) for (i in c.pts.indices) addMark(c, i)
        addHandle()
    }

    private fun addButton(c: Cfg) {
        val s = dp(c.size)
        val v = circle(c.label, s, 0xFF16A34A.toInt(), Color.WHITE, 14f)
        v.alpha = c.alpha / 100f
        val p = params(s, s, c.x, c.y)
        v.setOnTouchListener(
            Drag(v, p, { editing }, { x, y ->
                c.x = x
                c.y = y
                Store.save(this, cfgs)
            }, { if (!editing) tap(c) })
        )
        wm.addView(v, p)
        btnViews[c.id] = v
    }

    private fun addMark(c: Cfg, i: Int) {
        val s = dp(40)
        val pt = c.pts[i]
        val set = pt[0] >= 0 && pt[1] >= 0
        val cx = if (set) pt[0] else c.x + dp(c.size) + dp(30) + i * dp(46)
        val cy = if (set) pt[1] else c.y + dp(c.size) / 2
        val v = circle(c.label + "-" + (i + 1), s, 0x44FFD400, if (set) 0xFFFFD400.toInt() else 0xFFEF4444.toInt(), 10f)
        val p = params(s, s, cx - s / 2, cy - s / 2)
        v.setOnTouchListener(
            Drag(v, p, { true }, { x, y ->
                pt[0] = x + s / 2
                pt[1] = y + s / 2
                Store.save(this, cfgs)
            }, { })
        )
        wm.addView(v, p)
        markViews[c.id + "#" + i] = v
    }

    private fun addHandle() {
        val s = dp(40)
        val prefs = Store.prefs(this)
        val v = circle(if (editing) "✓" else "✎", s, 0xCC111111.toInt(), 0xFF22C55E.toInt(), 16f)
        val p = params(s, s, prefs.getInt("hx", dp(8)), prefs.getInt("hy", dp(80)))
        v.setOnTouchListener(
            Drag(v, p, { true }, { x, y ->
                prefs.edit().putInt("hx", x).putInt("hy", y).apply()
            }, {
                editing = !editing
                rebuild()
            })
        )
        wm.addView(v, p)
        handle = v
    }

    private fun tap(c: Cfg) {
        val pts = c.pts.filter { it[0] >= 0 && it[1] >= 0 }
        if (pts.isEmpty()) {
            Toast.makeText(this, "Nuqta belgilanmagan: ✎ ni bosing", Toast.LENGTH_SHORT).show()
            return
        }
        pts.forEachIndexed { i, p -> handler.postDelayed({ tapAt(p[0], p[1]) }, i * 450L) }
    }

    private fun tapAt(x: Int, y: Int) {
        val path = Path()
        path.moveTo(x.toFloat(), y.toFloat())
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        dispatchGesture(g, null, null)
    }

    private inner class Drag(
        val v: View,
        val p: WindowManager.LayoutParams,
        val canMove: () -> Boolean,
        val onMoved: (Int, Int) -> Unit,
        val onClick: () -> Unit
    ) : View.OnTouchListener {
        private var dx = 0f
        private var dy = 0f
        private var sx = 0
        private var sy = 0
        private var moved = false

        override fun onTouch(view: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX
                    dy = e.rawY
                    sx = p.x
                    sy = p.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> if (canMove()) {
                    val ox = (e.rawX - dx).toInt()
                    val oy = (e.rawY - dy).toInt()
                    if (Math.abs(ox) > dp(6) || Math.abs(oy) > dp(6)) moved = true
                    if (moved) {
                        p.x = sx + ox
                        p.y = sy + oy
                        wm.updateViewLayout(v, p)
                    }
                }
                MotionEvent.ACTION_UP -> if (moved) onMoved(p.x, p.y) else onClick()
            }
            return true
        }
    }
}
