package uz.example.bedrockhub

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private const val SITE_URL = "https://doston199108031-sudo.github.io/Blockhub/"
private const val ASSET_URL = "file:///android_asset/index.html"
private const val REQ_PICK = 101
private const val BEDROCK_PKG = "com.mojang.minecraftpe"
private const val GAME_PKG = "com.mastercraftnew.craftingbuilding"
private const val GAME_APK_URL =
    "https://github.com/doston199108031-sudo/Blockhub/releases/download/minicraft/Minicraft_PE_.apk"
private val BEDROCK_EXT = listOf(".mcpack", ".mcaddon", ".mcworld", ".mctemplate")
private val GAMES = linkedMapOf(
    BEDROCK_PKG to "Minecraft",
    "com.mojang.minecrafttrialpe" to "Minecraft Trial",
    GAME_PKG to "Minicraft PE"
)
private val OWN_HOSTS = listOf("doston199108031-sudo.github.io", "blockhub.uz", "www.blockhub.uz")

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var offline = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dark = Color.parseColor("#0B0F0C")
        window.statusBarColor = dark
        window.navigationBarColor = dark
        web = WebView(this)
        web.setBackgroundColor(dark)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.userAgentString = s.userAgentString + " BlokHubApp"

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                handle(request.url)

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) fallback(view)
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                if (request.isForMainFrame && errorResponse.statusCode >= 400) fallback(view)
            }
        }
        web.setDownloadListener { url, _, _, _, _ ->
            val name = File(Uri.parse(url).path ?: "file").name
            if (BEDROCK_EXT.any { name.lowercase().endsWith(it) }) downloadAndOpen(url, name) else openBrowser(url)
        }
        web.addJavascriptInterface(Bridge(), "BlokHubNative")
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        web.loadUrl(SITE_URL)
    }

    private fun fallback(view: WebView) {
        if (offline) return
        offline = true
        view.loadUrl(ASSET_URL)
    }

    private fun handle(u: Uri): Boolean {
        if (u.scheme == "blokhub") {
            if (u.host == "play") playGame(GAME_PKG)
            return true
        }
        val path = (u.path ?: "").lowercase()
        if (BEDROCK_EXT.any { path.endsWith(it) }) {
            downloadAndOpen(u.toString(), File(u.path ?: "file").name)
            return true
        }
        if (u.scheme == "http" || u.scheme == "https") {
            if (OWN_HOSTS.contains(u.host ?: "")) return false
            openBrowser(u.toString())
            return true
        }
        return false
    }

    /** Sahifadagi JS shu obyekt orqali (window.BlokHubNative) ilovaga murojaat qiladi. */
    inner class Bridge {
        @JavascriptInterface fun games(): String {
            val a = JSONArray()
            GAMES.forEach { (p, n) ->
                a.put(JSONObject().put("pkg", p).put("name", n).put("installed", packageManager.getLaunchIntentForPackage(p) != null))
            }
            return a.toString()
        }
        @JavascriptInterface fun getConfig(): String = Overlay.load(this@MainActivity)
        @JavascriptInterface fun saveConfig(json: String) { Overlay.save(this@MainActivity, json) }
        @JavascriptInterface fun status(): String =
            JSONObject().put("overlay", canOverlay()).put("keys", KeySender.shizukuReady()).toString()
        @JavascriptInterface fun grantOverlay() { runOnUiThread { requestOverlay() } }
        @JavascriptInterface fun grantShizuku() { runOnUiThread { requestShizuku() } }
        @JavascriptInterface fun play(pkg: String) { runOnUiThread { playGame(pkg) } }
        @JavascriptInterface fun libList(): String {
            val a = JSONArray()
            (libDir().listFiles() ?: emptyArray()).sortedByDescending { it.lastModified() }
                .forEach { a.put(JSONObject().put("name", it.name).put("size", it.length())) }
            return a.toString()
        }
        @JavascriptInterface fun libAdd() { runOnUiThread { pickFiles() } }
        @JavascriptInterface fun libSave(url: String) { saveToLibrary(url) }
        @JavascriptInterface fun libOpen(name: String) { runOnUiThread { openLib(name) } }
        @JavascriptInterface fun libDelete(name: String): Boolean = libFile(name).delete()
    }

    private fun canOverlay() = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)

    private fun requestOverlay() {
        Toast.makeText(this, "BlokHub uchun \"Boshqa ilovalar ustida ko'rsatish\"ni yoqing", Toast.LENGTH_LONG).show()
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (_: ActivityNotFoundException) { }
    }

    private fun requestShizuku() {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) Shizuku.requestPermission(7)
                return
            }
        } catch (_: Throwable) { }
        Toast.makeText(this, "Shizuku ishlamayapti. Shizuku'ni o'rnating va ishga tushiring.", Toast.LENGTH_LONG).show()
        openBrowser("https://shizuku.rikka.app/")
    }

    private fun playGame(pkg: String) {
        if (!GAMES.containsKey(pkg)) return
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) {
            if (pkg == GAME_PKG) {
                Toast.makeText(this, "Minicraft PE o'rnatilmagan. Yuklab olinmoqda...", Toast.LENGTH_LONG).show()
                openBrowser(GAME_APK_URL)
            } else openBrowser("https://play.google.com/store/apps/details?id=$pkg")
            return
        }
        if (Overlay.count(this) > 0) {
            if (!canOverlay()) { requestOverlay(); return }
            ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        }
        try { startActivity(launch) } catch (_: ActivityNotFoundException) { }
    }

    override fun onResume() {
        super.onResume()
        stopService(Intent(this, OverlayService::class.java)) // BlokHub'ga qaytganda tugmalar yashiriladi
    }

    // ---- Kutubxona: saqlangan xarita, resurs paket va boshqa fayllar ----
    private fun libDir() = File(filesDir, "library").apply { mkdirs() }
    private fun libFile(name: String) = File(libDir(), File(name).name)
    private fun safeName(n: String) = n.replace(Regex("[^\\w.\\- ()]"), "_").ifBlank { "file" }

    private fun uniqueFile(name: String): File {
        val n = safeName(name)
        var f = File(libDir(), n)
        val dot = n.lastIndexOf('.')
        val base = if (dot > 0) n.substring(0, dot) else n
        val ext = if (dot > 0) n.substring(dot) else ""
        var i = 1
        while (f.exists()) { f = File(libDir(), "$base ($i)$ext"); i++ }
        return f
    }

    private fun libChanged() {
        web.evaluateJavascript("if(window.libChanged)libChanged()", null)
    }

    private fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        try { startActivityForResult(i, REQ_PICK) } catch (_: ActivityNotFoundException) { }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { c -> for (k in 0 until c.itemCount) uris.add(c.getItemAt(k).uri) }
        data.data?.let { if (it !in uris) uris.add(it) }
        Thread {
            var ok = 0
            uris.forEach { u ->
                try {
                    val dest = uniqueFile(displayName(u))
                    contentResolver.openInputStream(u)?.use { inp -> dest.outputStream().use { out -> inp.copyTo(out) } }
                    ok++
                } catch (_: Exception) { }
            }
            runOnUiThread {
                Toast.makeText(this, "Saqlandi: $ok", Toast.LENGTH_SHORT).show()
                libChanged()
            }
        }.start()
    }

    private fun displayName(u: Uri): String {
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0) ?: "file"
        }
        return u.lastPathSegment ?: "file"
    }

    private fun saveToLibrary(url: String) {
        val u = Uri.parse(url)
        if (u.scheme != "https" && u.scheme != "http") return
        runOnUiThread { Toast.makeText(this, "Saqlanmoqda...", Toast.LENGTH_SHORT).show() }
        Thread {
            try {
                val dest = uniqueFile(File(u.path ?: "file").name)
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 60000
                c.instanceFollowRedirects = true
                if (c.responseCode != 200) throw RuntimeException("HTTP ${c.responseCode}")
                c.inputStream.use { inp -> dest.outputStream().use { out -> inp.copyTo(out) } }
                runOnUiThread {
                    Toast.makeText(this, "Saqlandi: ${dest.name}", Toast.LENGTH_SHORT).show()
                    libChanged()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Xato: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun openLib(name: String) {
        val f = libFile(name)
        if (!f.exists()) return
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        if (BEDROCK_EXT.any { f.name.lowercase().endsWith(it) }) { openInMinecraft(uri); return }
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(Intent.createChooser(i, f.name)) } catch (_: ActivityNotFoundException) { }
    }

    private fun downloadAndOpen(url: String, name: String) {
        val safe = name.replace(Regex("[^\\w.\\- ]"), "_")
        Toast.makeText(this, "Yuklanmoqda: $safe", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val dir = File(cacheDir, "downloads").apply { mkdirs() }
                val dest = File(dir, safe)
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 60000
                c.instanceFollowRedirects = true
                if (c.responseCode != 200) throw RuntimeException("HTTP ${c.responseCode}")
                c.inputStream.use { inp -> dest.outputStream().use { out -> inp.copyTo(out) } }
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", dest)
                runOnUiThread { openInMinecraft(uri) }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Xato: ${e.message}", Toast.LENGTH_LONG).show()
                    openBrowser(url)
                }
            }
        }.start()
    }

    private fun openInMinecraft(uri: Uri) {
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent(i).setPackage(BEDROCK_PKG))
        } catch (_: ActivityNotFoundException) {
            try { startActivity(Intent.createChooser(i, "Minecraft")) } catch (_: ActivityNotFoundException) { }
        }
    }

    private fun openBrowser(url: String) {
        if (url.isBlank()) return
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: ActivityNotFoundException) { }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
