plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "uz.example.bedrockhub"
    compileSdk = 34

    defaultConfig {
        applicationId = "uz.example.bedrockhub"
        minSdk = 24
        targetSdk = 34
        versionCode = 4
        versionName = "0.4.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // FileProvider (fayllarni Minecraft'ga xavfsiz uzatish) uchun
    implementation("androidx.core:core-ktx:1.13.1")
    // Boshqa ilovaga tugma yuborish (input keyevent) uchun
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
