package uz.example.bedrockhub

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private const val SITE_URL = "https://doston199108031-sudo.github.io/Blockhub/"
private const val ASSET_URL = "file:///android_asset/index.html"
private const val GAME_APK_URL =
    "https://github.com/doston199108031-sudo/Blockhub/releases/download/minicraft/Minicraft_PE_.apk"
private val BEDROCK_EXT = listOf(".mcpack", ".mcaddon", ".mcworld", ".mctemplate")
private val OWN_HOSTS = listOf("doston199108031-sudo.github.io", "blockhub.uz", "www.blockhub.uz")

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var offline = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dark = Color.parseColor("#0B0F0C")
        window.statusBarColor = dark
        window.navigationBarColor = dark
        web = WebView(this)
        web.setBackgroundColor(dark)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.userAgentString = s.userAgentString + " BlokHubApp"

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                handle(request.url)

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) fallback(view)
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                if (request.isForMainFrame && errorResponse.statusCode >= 400) fallback(view)
            }
        }
        web.setDownloadListener { url, _, _, _, _ ->
            val name = File(Uri.parse(url).path ?: "file").name
            if (BEDROCK_EXT.any { name.lowercase().endsWith(it) }) downloadAndOpen(url, name) else openBrowser(url)
        }
        web.loadUrl(SITE_URL)
    }

    private fun fallback(view: WebView) {
        if (offline) return
        offline = true
        view.loadUrl(ASSET_URL)
    }

    private fun handle(u: Uri): Boolean {
        if (u.scheme == "blokhub") {
            when (u.host) {
                "play" -> launchPkg("Minicraft PE", GAME_PKG)
                "settings" -> startActivity(Intent(this, SettingsActivity::class.java))
            }
            return true
        }
        val path = (u.path ?: "").lowercase()
        if (BEDROCK_EXT.any { path.endsWith(it) }) {
            downloadAndOpen(u.toString(), File(u.path ?: "file").name)
            return true
        }
        if (u.scheme == "http" || u.scheme == "https") {
            if (OWN_HOSTS.contains(u.host ?: "")) return false
            openBrowser(u.toString())
            return true
        }
        return false
    }

    private fun launchPkg(name: String, pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) {
            try { startActivity(i) } catch (_: ActivityNotFoundException) { }
            return
        }
        Toast.makeText(this, "$name o'rnatilmagan", Toast.LENGTH_LONG).show()
        openBrowser(if (pkg == BEDROCK_PKG) "https://play.google.com/store/apps/details?id=$pkg" else GAME_APK_URL)
    }

    private fun downloadAndOpen(url: String, name: String) {
        val safe = name.replace(Regex("[^\\w.\\- ]"), "_")
        Toast.makeText(this, "Yuklanmoqda: $safe", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val dir = File(cacheDir, "downloads").apply { mkdirs() }
                val dest = File(dir, safe)
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 60000
                c.instanceFollowRedirects = true
                if (c.responseCode != 200) throw RuntimeException("HTTP ${c.responseCode}")
                c.inputStream.use { inp -> dest.outputStream().use { out -> inp.copyTo(out) } }
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", dest)
                runOnUiThread { openInMinecraft(uri) }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Xato: ${e.message}", Toast.LENGTH_LONG).show()
                    openBrowser(url)
                }
            }
        }.start()
    }

    private fun openInMinecraft(uri: Uri) {
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent(i).setPackage(BEDROCK_PKG))
        } catch (_: ActivityNotFoundException) {
            try { startActivity(Intent.createChooser(i, "Minecraft")) } catch (_: ActivityNotFoundException) { }
        }
    }

    private fun openBrowser(url: String) {
        if (url.isBlank()) return
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: ActivityNotFoundException) { }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
