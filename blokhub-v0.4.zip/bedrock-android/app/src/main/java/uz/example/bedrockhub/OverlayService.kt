package uz.example.bedrockhub

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

/** Tugmalar sozlamasi (SharedPreferences'da JSON). x, y: tugma markazi, ekran ulushi (0..1); size: dp; opacity: 0.1..1 */
object Overlay {
    const val DEFAULT = """{"buttons":[
{"id":"d1","label":"Q","key":"Q","x":0.92,"y":0.2,"size":52,"opacity":0.75},
{"id":"d2","label":"F5","key":"F5","x":0.92,"y":0.38,"size":52,"opacity":0.75},
{"id":"d3","label":"F1","key":"F1","x":0.92,"y":0.56,"size":52,"opacity":0.75}]}"""

    private fun prefs(c: Context) = c.getSharedPreferences("blokhub", Context.MODE_PRIVATE)
    fun load(c: Context): String = prefs(c).getString("cfg", null) ?: DEFAULT
    fun save(c: Context, json: String) {
        try { JSONObject(json).getJSONArray("buttons") } catch (_: Exception) { return }
        prefs(c).edit().putString("cfg", json).apply()
    }
    fun count(c: Context): Int = try { JSONObject(load(c)).getJSONArray("buttons").length() } catch (_: Exception) { 0 }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val views = mutableListOf<View>()
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startFg()
        rebuild()
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        rebuild()
    }

    override fun onDestroy() { clear(); super.onDestroy() }

    private fun clear() {
        views.forEach { try { wm.removeView(it) } catch (_: Exception) { } }
        views.clear()
    }

    private fun rebuild() {
        clear()
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        val arr = try { JSONObject(Overlay.load(this)).getJSONArray("buttons") } catch (_: Exception) { return }
        val dens = resources.displayMetrics.density
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val key = o.optString("key").uppercase()
            if (key.isEmpty()) continue
            val label = o.optString("label", key).take(5).ifEmpty { key }
            val size = (o.optDouble("size", 52.0).coerceIn(28.0, 120.0) * dens).toInt()
            val op = o.optDouble("opacity", 0.75).coerceIn(0.1, 1.0).toFloat()
            val cx = o.optDouble("x", 0.5).coerceIn(0.0, 1.0) * dm.widthPixels
            val cy = o.optDouble("y", 0.5).coerceIn(0.0, 1.0) * dm.heightPixels

            val v = TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setTextSize(TypedValue.COMPLEX_UNIT_PX, size * 0.3f)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xE60A0F0C.toInt())
                    setStroke((2 * dens).toInt(), 0xFF22C55E.toInt())
                }
                alpha = op
            }
            v.setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_DOWN) v.alpha = 1f
                if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) v.alpha = op
                false
            }
            v.setOnClickListener {
                Thread {
                    if (!KeySender.send(key)) main.post {
                        Toast.makeText(this, "Tugma yuborilmadi. BlokHub sozlamalarida Shizuku'ni yoqing.", Toast.LENGTH_LONG).show()
                    }
                }.start()
            }
            val lp = WindowManager.LayoutParams(
                size, size, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = (cx - size / 2).toInt().coerceIn(0, maxOf(0, dm.widthPixels - size))
                y = (cy - size / 2).toInt().coerceIn(0, maxOf(0, dm.heightPixels - size))
            }
            try { wm.addView(v, lp); views.add(v) } catch (_: Exception) { }
        }
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel(CH, "BlokHub tugmalari", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else @Suppress("DEPRECATION") Notification.Builder(this)
        @Suppress("DEPRECATION")
        val n = b.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("BlokHub")
            .setContentText("Minecraft tugmalari yoqilgan")
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "O'chirish", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    companion object {
        const val ACTION_STOP = "uz.example.bedrockhub.STOP"
        private const val CH = "overlay"
    }
}
