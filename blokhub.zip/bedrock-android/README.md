# Bedrock Hub: Android (norasmiy)

Minecraft Bedrock (Android) uchun add-on launcher. Loyiha Android Studio / Gradle loyihasi.

## APK olish (eng oson: GitHub Actions)
1. Bu papkani GitHub'dagi yangi repoga yuklang.
2. Repo'da **Actions → Build APK → Run workflow** ni bosing.
3. Tugagach **Artifacts → BedrockHub-debug-apk** dan `app-debug.apk` ni yuklab oling.

## APK olish (Android Studio)
1. Android Studio'da papkani oching (Gradle o'zi sinxronlanadi).
2. **Build → Build APK(s)**. Fayl: `app/build/outputs/apk/debug/app-debug.apk`.

## Telefonga o'rnatish
APK'ni telefonga ko'chiring va "noma'lum manbalardan o'rnatish" ruxsatini bering.

## Imkoniyatlar
- O'YNASH: o'rnatilgan Minecraft Bedrock'ni ochadi (yo'q bo'lsa Google Play'ni ochadi).
- Katalog: CurseForge'dan Bedrock kontentini qidiradi va Minecraft'ga import qiladi (API kalit kerak: console.curseforge.com).
- Fayllar: .mcpack/.mcaddon/.mcworld/.mctemplate fayllarni tanlab import qiladi.

## Cheklovlar
- Kod hali kompilyatsiya qilib sinalmagan prototip; xato chiqsa, Gradle xabarini yuboring.
- Import Minecraft'ning fayl ochish imkoniyatiga tayanadi; qurilmaga qarab chooser chiqishi mumkin.
- Ba'zi mualliflar tashqi yuklashni o'chirgan, bunday kontentni saytdan qo'lda yuklash kerak.
- O'yin litsenziyali bo'lishi kerak, ilova uni tarqatmaydi.
