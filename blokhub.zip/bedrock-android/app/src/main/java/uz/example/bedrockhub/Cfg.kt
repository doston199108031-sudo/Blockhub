package uz.example.bedrockhub

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

const val BEDROCK_PKG = "com.mojang.minecraftpe"
const val GAME_PKG = "com.mastercraftnew.craftingbuilding"
val GAME_PKGS = setOf(BEDROCK_PKG, GAME_PKG)

class Cfg(
    var id: String,
    var label: String,
    var enabled: Boolean = true,
    var size: Int = 56,
    var alpha: Int = 80,
    var x: Int = 40,
    var y: Int = 300,
    var tx: Int = -1,
    var ty: Int = -1
)

object Store {
    fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Cfg> {
        val raw = prefs(c).getString("buttons", null)
        val out = mutableListOf<Cfg>()
        if (raw != null) {
            try {
                val a = JSONArray(raw)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(
                        Cfg(
                            o.getString("id"), o.getString("label"), o.optBoolean("enabled", true),
                            o.optInt("size", 56), o.optInt("alpha", 80), o.optInt("x", 40), o.optInt("y", 300),
                            o.optInt("tx", -1), o.optInt("ty", -1)
                        )
                    )
                }
            } catch (_: Exception) {
                out.clear()
            }
        }
        if (out.isEmpty()) {
            out.add(Cfg("q", "Q", y = 300))
            out.add(Cfg("f5", "F5", y = 450))
            out.add(Cfg("f1", "F1", y = 600))
        }
        return out
    }

    fun save(c: Context, list: List<Cfg>) {
        val a = JSONArray()
        for (b in list) {
            a.put(
                JSONObject().put("id", b.id).put("label", b.label).put("enabled", b.enabled)
                    .put("size", b.size).put("alpha", b.alpha).put("x", b.x).put("y", b.y)
                    .put("tx", b.tx).put("ty", b.ty)
            )
        }
        prefs(c).edit().putString("buttons", a.toString()).apply()
    }
}
