package uz.example.bedrockhub

// Til indekslari: 0 = O'zbekcha, 1 = Русский, 2 = English
internal var langIdx = 0

private fun e(uz: String, ru: String, en: String) = arrayOf(uz, ru, en)

private val S: Map<String, Array<String>> = mapOf(
    // Tablar
    "tab_home" to e("Bosh", "Главная", "Home"),
    "tab_hasan" to e("HasanMC modlari", "Моды HasanMC", "HasanMC mods"),
    "tab_mods" to e("Modlar", "Моды", "Mods"),
    "tab_maps" to e("Xaritalar", "Карты", "Maps"),
    "tab_tex" to e("Teksturalar", "Текстуры", "Textures"),
    "tab_mine" to e("Mening modlarim", "Мои моды", "My mods"),
    "tab_guide" to e("Qo'llanma", "Руководство", "Guide"),
    "tab_settings" to e("Sozlamalar", "Настройки", "Settings"),

    // Bosh
    "home_sub" to e(
        "Minecraft Bedrock uchun add-on (mod), xarita va teksturalar katalogi.",
        "Каталог аддонов (модов), карт и текстур для Minecraft Bedrock.",
        "Catalog of add-ons (mods), maps and textures for Minecraft Bedrock."),
    "play" to e("▶  O'YNASH", "▶  ИГРАТЬ", "▶  PLAY"),
    "play_missing" to e(
        "Minecraft Bedrock o'rnatilmagan. Google Play'dan o'rnating.",
        "Minecraft Bedrock не установлен. Установите его из Google Play.",
        "Minecraft Bedrock is not installed. Install it from Google Play."),
    "unofficial" to e(
        "Norasmiy ilova. Mojang yoki Microsoft bilan bog'liq emas.",
        "Неофициальное приложение. Не связано с Mojang или Microsoft.",
        "Unofficial app. Not affiliated with Mojang or Microsoft."),

    // Katalog
    "title_mods" to e("Modlar (add-onlar)", "Моды (аддоны)", "Mods (add-ons)"),
    "title_maps" to e("Xaritalar", "Карты", "Maps"),
    "title_tex" to e("Teksturalar", "Текстуры", "Textures"),
    "search_hint" to e("Qidirish…", "Поиск…", "Search…"),
    "version_btn" to e("Versiya: %s", "Версия: %s", "Version: %s"),
    "all" to e("Hammasi", "Все", "All"),
    "search_btn" to e("Qidirish", "Найти", "Search"),
    "version_dialog" to e("Bedrock versiyasi", "Версия Bedrock", "Bedrock version"),
    "no_key" to e(
        "Sozlamalarda CurseForge API kalitini kiriting.",
        "Введите ключ CurseForge API в настройках.",
        "Enter your CurseForge API key in Settings."),
    "searching" to e("Qidirilmoqda…", "Поиск…", "Searching…"),
    "none_found" to e("Hech narsa topilmadi.", "Ничего не найдено.", "Nothing found."),
    "n_results" to e("%d ta natija", "Найдено: %d", "%d results"),
    "versions_lbl" to e("Versiyalar: %s", "Версии: %s", "Versions: %s"),
    "downloads_lbl" to e("Yuklashlar: %d", "Загрузок: %d", "Downloads: %d"),
    "install_btn" to e("O'rnatish", "Установить", "Install"),
    "loading_btn" to e("Yuklanmoqda…", "Загрузка…", "Downloading…"),
    "err" to e("Xato: %s", "Ошибка: %s", "Error: %s"),
    "file_missing" to e("Fayl topilmadi.", "Файл не найден.", "File not found."),
    "ext_disabled" to e(
        "Muallif tashqi yuklashni o'chirgan. Sayt ochildi, o'sha yerdan yuklang.",
        "Автор отключил загрузку из приложений. Открыт сайт, скачайте файл там.",
        "The author disabled third-party downloads. The site was opened, download the file there."),
    "not_bedrock" to e(
        "Fayl (%s) Bedrock formatida emas. Sayt ochildi, o'sha yerdan yuklang.",
        "Файл (%s) не в формате Bedrock. Открыт сайт, скачайте файл там.",
        "The file (%s) is not in a Bedrock format. The site was opened, download it there."),
    "sent" to e("%s Minecraft'ga yuborildi.", "%s отправлен в Minecraft.", "%s was sent to Minecraft."),

    // Mening modlarim
    "mine_title" to e("Mening modlarim", "Мои моды", "My mods"),
    "mine_desc" to e(
        "Telefoningizdagi .mcpack, .mcaddon, .mcworld yoki .mctemplate fayllarni tanlang. Tanlanganlar pastda saqlanadi, istalgan vaqt Minecraft'ga yuborasiz.",
        "Выберите файлы .mcpack, .mcaddon, .mcworld или .mctemplate на телефоне. Выбранные файлы сохраняются ниже, их можно отправить в Minecraft в любое время.",
        "Pick .mcpack, .mcaddon, .mcworld or .mctemplate files on your phone. They are saved below and you can send them to Minecraft any time."),
    "pick_btn" to e("Fayl tanlash", "Выбрать файл", "Pick files"),
    "mine_empty" to e("Hozircha fayl yo'q.", "Пока нет файлов.", "No files yet."),
    "send_btn" to e("Minecraft'ga yuborish", "Отправить в Minecraft", "Send to Minecraft"),
    "delete_btn" to e("O'chirish", "Удалить", "Remove"),
    "open_fail" to e(
        "Faylni ochib bo'lmadi, uni qayta tanlang.",
        "Не удалось открыть файл, выберите его снова.",
        "Could not open the file, pick it again."),
    "added" to e(
        "%d ta fayl qo'shildi. Yuborish tugmasini bosing.",
        "Добавлено файлов: %d. Нажмите «Отправить в Minecraft».",
        "%d file(s) added. Tap Send to Minecraft."),

    // HasanMC
    "hasan_title" to e("HasanMC modlari", "Моды HasanMC", "HasanMC mods"),
    "hasan_sub" to e("Muallifning o'z modlari.", "Собственные моды автора.", "The author's own mods."),
    "refresh" to e("Yangilash", "Обновить", "Refresh"),
    "need_url" to e(
        "Sozlamalarda HasanMC katalog havolasini (https://…) kiriting.",
        "Введите ссылку на каталог HasanMC (https://…) в настройках.",
        "Enter the HasanMC catalog link (https://…) in Settings."),
    "loading" to e("Yuklanmoqda…", "Загрузка…", "Loading…"),
    "no_mods_yet" to e("Hozircha mod yo'q.", "Пока нет модов.", "No mods yet."),
    "n_mods" to e("%d ta mod", "Модов: %d", "%d mods"),
    "cat_missing" to e("Katalog topilmadi (%d)", "Каталог не найден (%d)", "Catalog not found (%d)"),
    "https_needed" to e(
        "Mod havolasi https bilan boshlanishi kerak.",
        "Ссылка на мод должна начинаться с https.",
        "The mod link must start with https."),
    "bad_type" to e(
        "Fayl turi .mcpack, .mcaddon, .mcworld yoki .mctemplate bo'lishi kerak.",
        "Тип файла должен быть .mcpack, .mcaddon, .mcworld или .mctemplate.",
        "The file type must be .mcpack, .mcaddon, .mcworld or .mctemplate."),
    "nameless" to e("Nomsiz", "Без названия", "Untitled"),

    // Sozlamalar
    "set_title" to e("Sozlamalar", "Настройки", "Settings"),
    "lang_label" to e("Til", "Язык", "Language"),
    "cf_label" to e(
        "CurseForge API kaliti (bepul: console.curseforge.com). Katalog ishlashi uchun kerak.",
        "Ключ CurseForge API (бесплатно: console.curseforge.com). Нужен для работы каталога.",
        "CurseForge API key (free: console.curseforge.com). Required for the catalog."),
    "hasan_label" to e(
        "HasanMC katalog havolasi (https://… .json)",
        "Ссылка на каталог HasanMC (https://… .json)",
        "HasanMC catalog link (https://… .json)"),
    "save_btn" to e("Saqlash", "Сохранить", "Save"),
    "saved" to e("Saqlandi.", "Сохранено.", "Saved."),

    // Qo'llanma
    "g_title" to e("Qo'llanma", "Руководство", "Guide"),
    "g_h1" to e("Add-on (mod) o'rnatish", "Установка аддона (мода)", "Installing an add-on (mod)"),
    "g_p1" to e(
        "1. Modlar bo'limidan add-on tanlang va \"O'rnatish\" ni bosing.\n" +
            "2. Fayl Minecraft'da ochiladi va import xabari chiqadi.\n" +
            "3. Minecraft'da dunyo yarating yoki mavjud dunyoni tahrirlang (qalam belgisi).\n" +
            "4. \"Behavior Packs\" va \"Resource Packs\" bo'limlarida add-onni yoqing.\n" +
            "5. Agar add-on talab qilsa, dunyo sozlamalarida \"Experiments\" funksiyalarini yoqing.",
        "1. В разделе «Моды» выберите аддон и нажмите «Установить».\n" +
            "2. Файл откроется в Minecraft, появится сообщение об импорте.\n" +
            "3. В Minecraft создайте мир или откройте настройки существующего (значок карандаша).\n" +
            "4. В разделах «Behavior Packs» и «Resource Packs» включите аддон.\n" +
            "5. Если аддон требует, включите экспериментальные функции («Experiments») в настройках мира.",
        "1. In the Mods section pick an add-on and tap Install.\n" +
            "2. The file opens in Minecraft and an import message appears.\n" +
            "3. In Minecraft create a world or edit an existing one (pencil icon).\n" +
            "4. Enable the add-on under Behavior Packs and Resource Packs.\n" +
            "5. If the add-on requires it, turn on Experiments in the world settings."),
    "g_h2" to e("Xarita o'rnatish", "Установка карты", "Installing a map"),
    "g_p2" to e(
        "Xaritalar bo'limidan tanlab o'rnating. .mcworld fayl Minecraft'ga import bo'ladi va \"Play\" → \"Worlds\" ro'yxatida paydo bo'ladi.",
        "Выберите карту в разделе «Карты» и установите её. Файл .mcworld импортируется в Minecraft и появится в списке «Play» → «Worlds».",
        "Pick a map in the Maps section and install it. The .mcworld file is imported into Minecraft and appears under Play → Worlds."),
    "g_h3" to e("Tekstura (resource pack)", "Текстуры (ресурспак)", "Textures (resource pack)"),
    "g_p3" to e(
        "Teksturalar bo'limidan o'rnating. So'ng Settings → Global Resources orqali yoki dunyo sozlamalarida paketni yoqing.",
        "Установите пак в разделе «Текстуры», затем включите его в Settings → Global Resources или в настройках мира.",
        "Install it from the Textures section, then enable the pack in Settings → Global Resources or in the world settings."),
    "g_h4" to e("Versiya muhim", "Версия важна", "The version matters"),
    "g_p4" to e(
        "Add-on ko'pincha aniq Minecraft versiyasi uchun yoziladi. Katalogda versiya filtrini ishlating va o'yiningiz versiyasiga mosini tanlang. Mos kelmasa, add-on ishlamasligi mumkin.",
        "Аддоны часто пишутся под конкретную версию Minecraft. Используйте фильтр версий и выберите подходящую вашей игре. Если версия не совпадает, аддон может не работать.",
        "Add-ons are often made for a specific Minecraft version. Use the version filter and pick the one that matches your game. A mismatched add-on may not work."),
    "g_h5" to e("Fayl yuklanmasa", "Если файл не скачивается", "If a file will not download"),
    "g_p5" to e(
        "Ba'zi mualliflar ilovadan yuklashni o'chirgan. Bunda ilova sayt sahifasini ochadi, faylni o'sha yerdan yuklab, \"Mening modlarim\" bo'limidan tanlang.",
        "Некоторые авторы отключили загрузку из приложений. Тогда приложение откроет страницу сайта: скачайте файл там и выберите его в разделе «Мои моды».",
        "Some authors disabled downloads from apps. The app then opens the site page: download the file there and pick it in My mods."),
    "g_h6" to e("Eslatma", "Примечание", "Note"),
    "g_p6" to e(
        "Bedrock'da Forge yoki Fabric kabi loaderlar yo'q: modlar o'rnini add-onlar bosadi. Ilova norasmiy va faqat litsenziyali o'yin bilan ishlaydi.",
        "В Bedrock нет загрузчиков вроде Forge или Fabric: модами служат аддоны. Приложение неофициальное и работает только с лицензионной игрой.",
        "Bedrock has no loaders like Forge or Fabric: add-ons serve as mods. The app is unofficial and works only with a licensed copy of the game.")
)

internal fun t(key: String): String = S[key]?.getOrNull(langIdx) ?: key

internal fun tf(key: String, vararg args: Any): String = String.format(t(key), *args)
