package uz.example.bedrockhub

import android.hardware.input.InputManager
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent

/**
 * Shizuku orqali (shell huquqi bilan) `app_process` da ishga tushadi.
 * stdin dan "down <kod>" va "up <kod>" buyruqlarini o'qib, haqiqiy tugma bosish/qo'yib yuborish hodisalarini yuboradi.
 */
object KeyHelper {
    @JvmStatic
    fun main(args: Array<String>) {
        val mgr = InputManager::class.java.getMethod("getInstance").invoke(null)
        val inject = InputManager::class.java.getMethod(
            "injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType
        )
        val reader = System.`in`.bufferedReader()
        while (true) {
            val line = reader.readLine() ?: break
            val p = line.trim().split(" ")
            if (p.size < 2) continue
            val code = p[1].toIntOrNull() ?: continue
            val action = when (p[0]) {
                "down" -> KeyEvent.ACTION_DOWN
                "up" -> KeyEvent.ACTION_UP
                else -> continue
            }
            val now = SystemClock.uptimeMillis()
            val ev = KeyEvent(now, now, action, code, 0, 0, -1, 0, 0, InputDevice.SOURCE_KEYBOARD)
            inject.invoke(mgr, ev, 0)
        }
    }
}
