package uz.example.bedrockhub

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

const val BEDROCK_PKG = "com.mojang.minecraftpe"
const val GAME_PKG = "com.mastercraftnew.craftingbuilding"
val GAME_PKGS = setOf(GAME_PKG)

/** pts: ketma-ket bosiladigan ekran nuqtalari (x, y). [-1, -1] = belgilanmagan. */
class Cfg(
    var id: String,
    var label: String,
    var enabled: Boolean = true,
    var size: Int = 56,
    var alpha: Int = 80,
    var x: Int = 40,
    var y: Int = 300,
    var pts: MutableList<IntArray> = mutableListOf(intArrayOf(-1, -1))
)

object Store {
    fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Cfg> {
        val raw = prefs(c).getString("buttons", null)
        val out = mutableListOf<Cfg>()
        if (raw != null) {
            try {
                val a = JSONArray(raw)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val pts = mutableListOf<IntArray>()
                    val pa = o.optJSONArray("pts")
                    if (pa != null) {
                        for (k in 0 until pa.length()) {
                            val p = pa.getJSONArray(k)
                            pts.add(intArrayOf(p.getInt(0), p.getInt(1)))
                        }
                    } else {
                        pts.add(intArrayOf(o.optInt("tx", -1), o.optInt("ty", -1)))
                    }
                    if (pts.isEmpty()) pts.add(intArrayOf(-1, -1))
                    out.add(
                        Cfg(
                            o.getString("id"), o.getString("label"), o.optBoolean("enabled", true),
                            o.optInt("size", 56), o.optInt("alpha", 80), o.optInt("x", 40), o.optInt("y", 300), pts
                        )
                    )
                }
            } catch (_: Exception) {
                out.clear()
            }
        }
        if (out.isEmpty()) {
            out.add(Cfg("q", "Q", y = 300))
            out.add(Cfg("f5", "F5", y = 450))
            out.add(Cfg("f1", "F1", y = 600))
            out.add(Cfg("zoom", "ZOOM", y = 750))
        } else if (!prefs(c).getBoolean("zoom_added", false)) {
            if (out.none { it.id == "zoom" }) out.add(Cfg("zoom", "ZOOM", y = 750))
            prefs(c).edit().putBoolean("zoom_added", true).apply()
            save(c, out)
        }
        return out
    }

    fun save(c: Context, list: List<Cfg>) {
        val a = JSONArray()
        for (b in list) {
            val pa = JSONArray()
            for (p in b.pts) pa.put(JSONArray().put(p[0]).put(p[1]))
            a.put(
                JSONObject().put("id", b.id).put("label", b.label).put("enabled", b.enabled)
                    .put("size", b.size).put("alpha", b.alpha).put("x", b.x).put("y", b.y)
                    .put("pts", pa)
            )
        }
        prefs(c).edit().putString("buttons", a.toString()).apply()
    }
}
