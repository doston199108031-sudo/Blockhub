package uz.example.bedrockhub

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

private const val BG = 0xFF0B0F0C.toInt()
private const val PANEL = 0xFF161C17.toInt()
private const val GREEN = 0xFF22C55E.toInt()
private const val MUTED = 0xFF9CA3AF.toInt()

class SettingsActivity : Activity() {
    private lateinit var box: LinearLayout
    private var list: MutableList<Cfg> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val sv = ScrollView(this)
        sv.setBackgroundColor(BG)
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(16), dp(16), dp(32))
        sv.addView(box)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val x = TextView(this)
        x.text = t
        x.textSize = size
        x.setTextColor(color)
        if (bold) x.typeface = Typeface.DEFAULT_BOLD
        x.setPadding(0, dp(6), 0, dp(6))
        return x
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setTextColor(Color.BLACK)
        b.setBackgroundColor(GREEN)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun slider(min: Int, max: Int, cur: Int, onChange: (Int) -> Unit): SeekBar {
        val s = SeekBar(this)
        s.max = max - min
        s.progress = cur - min
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p + min)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        return s
    }

    private fun commit() {
        Store.save(this, list)
        TapService.instance?.refresh()
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(packageName) && s.contains("TapService")
    }

    private fun build() {
        box.removeAllViews()
        list = Store.load(this)
        box.addView(tv("Minecraft sozlamalari", 22f, GREEN, true))
        box.addView(
            tv(
                if (serviceOn()) "Tugmalar xizmati: yoqilgan"
                else "Tugmalar xizmati o'chiq. Maxsus imkoniyatlarda \"BlokHub tugmalari\" ni toping va yoqing.",
                14f, MUTED
            )
        )
        box.addView(button("Maxsus imkoniyatlarni ochish") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        box.addView(
            tv(
                "Qo'llanma: Minecraft'ga kiring, ✎ tugmasini bosing. Yashil tugmalarni suring, " +
                    "sariq doirani o'yin ekranidagi kerakli joyga qo'ying (masalan, kamera tugmasi ustiga), " +
                    "so'ng ✓ ni bosing. Tugma bosilganda shu nuqtaga bosiladi. " +
                    "Haqiqiy klaviatura tugmalari ishlamaydi.",
                13f, MUTED
            )
        )
        for (c in list) box.addView(card(c))
        val add = button("+ Tugma qo'shish") {
            list.add(Cfg("c" + System.currentTimeMillis(), "T", y = (300 + list.size * 150) % 1200))
            commit()
            build()
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(16)
        box.addView(add, lp)
    }

    private fun card(c: Cfg): LinearLayout {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundColor(PANEL)
        card.setPadding(dp(12), dp(8), dp(12), dp(12))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(12)
        card.layoutParams = lp

        val cb = CheckBox(this)
        cb.text = "Yoqilgan"
        cb.isChecked = c.enabled
        cb.setTextColor(Color.WHITE)
        cb.setOnCheckedChangeListener { _, on ->
            c.enabled = on
            commit()
        }
        card.addView(cb)

        val et = EditText(this)
        et.setText(c.label)
        et.setTextColor(Color.WHITE)
        et.setSingleLine()
        et.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(6))
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val t = s?.toString() ?: ""
                c.label = if (t.isBlank()) "?" else t
                commit()
            }

            override fun beforeTextChanged(s: CharSequence?, st: Int, c1: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c2: Int) {}
        })
        card.addView(et)

        val l1 = tv("O'lcham: ${c.size}", 13f, MUTED)
        card.addView(l1)
        card.addView(slider(32, 120, c.size) {
            c.size = it
            l1.text = "O'lcham: $it"
            commit()
        })
        val l2 = tv("Shaffoflik (ko'rinish): ${c.alpha}%", 13f, MUTED)
        card.addView(l2)
        card.addView(slider(20, 100, c.alpha) {
            c.alpha = it
            l2.text = "Shaffoflik (ko'rinish): $it%"
            commit()
        })
        if (c.id != "q" && c.id != "f5" && c.id != "f1") {
            card.addView(button("O'chirish") {
                list.remove(c)
                commit()
                build()
            })
        }
        return card
    }
}
