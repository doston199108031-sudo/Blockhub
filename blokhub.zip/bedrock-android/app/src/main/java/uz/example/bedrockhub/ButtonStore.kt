package uz.example.bedrockhub

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class PadButton(
    var id: Long,
    var label: String,
    var xf: Float,   // chap chet, ekran kengligining ulushi (0..1)
    var yf: Float,   // yuqori chet, ekran balandligining ulushi (0..1)
    var tx: Float,   // bosiladigan nuqta X, % (-1 = belgilanmagan)
    var ty: Float,   // bosiladigan nuqta Y, %
    var size: Int,   // dp
    var alpha: Int   // 10..100
)

object ButtonStore {
    private fun p(c: Context) = c.getSharedPreferences("pad", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<PadButton> {
        val raw = p(c).getString("buttons", null)
        val list = mutableListOf<PadButton>()
        if (raw == null) {
            listOf("Q", "F5", "F1").forEachIndexed { i, l ->
                list.add(PadButton(System.nanoTime() + i, l, 0.04f, 0.25f + 0.17f * i, -1f, -1f, 56, 70))
            }
            save(c, list)
            return list
        }
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                PadButton(
                    o.getLong("id"), o.getString("label"),
                    o.getDouble("xf").toFloat(), o.getDouble("yf").toFloat(),
                    o.getDouble("tx").toFloat(), o.getDouble("ty").toFloat(),
                    o.getInt("size"), o.getInt("alpha")
                )
            )
        }
        return list
    }

    fun save(c: Context, list: List<PadButton>) {
        val arr = JSONArray()
        list.forEach { b ->
            val o = JSONObject()
            o.put("id", b.id)
            o.put("label", b.label)
            o.put("xf", b.xf.toDouble())
            o.put("yf", b.yf.toDouble())
            o.put("tx", b.tx.toDouble())
            o.put("ty", b.ty.toDouble())
            o.put("size", b.size)
            o.put("alpha", b.alpha)
            arr.put(o)
        }
        p(c).edit().putString("buttons", arr.toString()).apply()
    }

    fun flag(c: Context, key: String, def: Boolean = false): Boolean = p(c).getBoolean(key, def)
    fun setFlag(c: Context, key: String, v: Boolean) { p(c).edit().putBoolean(key, v).apply() }
    fun gamePkg(c: Context): String = p(c).getString("gamePkg", "") ?: ""
    fun setGamePkg(c: Context, v: String) { p(c).edit().putString("gamePkg", v).apply() }
}
