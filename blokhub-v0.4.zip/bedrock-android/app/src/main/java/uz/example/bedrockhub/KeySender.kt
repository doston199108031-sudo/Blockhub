package uz.example.bedrockhub

import android.content.pm.PackageManager
import android.view.KeyEvent
import rikka.shizuku.Shizuku

/**
 * Android oddiy ilovaga boshqa ilovaga tugma yuborishga ruxsat bermaydi.
 * Shuning uchun `input keyevent` buyrug'i Shizuku (ADB huquqi) yoki root orqali bajariladi.
 */
object KeySender {
    fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun send(key: String): Boolean {
        val code = KeyEvent.keyCodeFromString("KEYCODE_" + key.uppercase())
        if (code == KeyEvent.KEYCODE_UNKNOWN) return false
        if (shizukuReady()) {
            try {
                val m = Shizuku::class.java.getDeclaredMethod(
                    "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
                )
                m.isAccessible = true
                val p = m.invoke(null, arrayOf("input", "keyevent", code.toString()), null, null) as Process
                return p.waitFor() == 0
            } catch (_: Throwable) { }
        }
        return try {
            Runtime.getRuntime().exec(arrayOf("su", "-c", "input keyevent $code")).waitFor() == 0
        } catch (_: Throwable) { false }
    }
}
