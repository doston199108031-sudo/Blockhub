# Bedrock Hub: Android (norasmiy)

Minecraft Bedrock (Android) uchun add-on launcher. Loyiha Android Studio / Gradle loyihasi.

## APK olish (eng oson: GitHub Actions)
1. Bu papkani GitHub'dagi yangi repoga yuklang.
2. Repo'da **Actions → Build APK → Run workflow** ni bosing.
3. Tugagach **Artifacts → BedrockHub-debug-apk** dan `app-debug.apk` ni yuklab oling.

## APK olish (Android Studio)
1. Android Studio'da papkani oching (Gradle o'zi sinxronlanadi).
2. **Build → Build APK(s)**. Fayl: `app/build/outputs/apk/debug/app-debug.apk`.

## Telefonga o'rnatish
APK'ni telefonga ko'chiring va "noma'lum manbalardan o'rnatish" ruxsatini bering.

## Imkoniyatlar
- O'YNASH: o'rnatilgan Minecraft Bedrock'ni ochadi (yo'q bo'lsa Google Play'ni ochadi).
- Katalog: CurseForge'dan Bedrock kontentini qidiradi va Minecraft'ga import qiladi (API kalit kerak: console.curseforge.com).
- Fayllar: .mcpack/.mcaddon/.mcworld/.mctemplate fayllarni tanlab import qiladi.

## Minecraft tugmalari (v0.3)
- O'YNASH bosilganda Minecraft tanlash oynasi chiqadi (Minecraft, Trial, Minicraft PE) va "Minecraft sozlamalari" tugmasi bor.
- Sozlamalarda tugma qo'shish (Q, F5, F1, F3, E, T, F11 yoki istalgan harf), surib joyini, kattaligini va shaffofligini o'zgartirish mumkin.
- Tugmalar o'yin ustida "Boshqa ilovalar ustida ko'rsatish" ruxsati bilan chiqadi. BlokHub'ga qaytganda yashiriladi.
- Tugma bosishni boshqa ilovaga yuborish uchun **Shizuku** (yoki root) kerak: Shizuku'ni o'rnatib ishga tushiring, so'ng sozlamalarda "Yoqish" ni bosing.
- Ilova avval https://doston199108031-sudo.github.io/Blockhub/ ni ochadi: yangi index.html'ni shu saytga ham yuklang.

## Mening fayllarim (v0.4)
- Xarita, resurs paket, add-on, shablon va boshqa fayllarni ilova ichida saqlash: "Fayl qo'shish" (telefondan tanlash) yoki mod ro'yxatidagi "Saqlash".
- Saqlangan fayl "Ochish" bilan Minecraft'ga import qilinadi (.mcworld/.mcpack/.mcaddon/.mctemplate), boshqa turlar tanlov oynasi orqali ochiladi.
- Fayllar ilovaning shaxsiy papkasida turadi; ilova o'chirilsa ular ham o'chadi.

## Cheklovlar
- Kod hali kompilyatsiya qilib sinalmagan prototip; xato chiqsa, Gradle xabarini yuboring.
- Import Minecraft'ning fayl ochish imkoniyatiga tayanadi; qurilmaga qarab chooser chiqishi mumkin.
- Ba'zi mualliflar tashqi yuklashni o'chirgan, bunday kontentni saytdan qo'lda yuklash kerak.
- O'yin litsenziyali bo'lishi kerak, ilova uni tarqatmaydi.
