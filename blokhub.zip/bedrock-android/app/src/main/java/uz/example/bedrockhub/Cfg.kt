package uz.example.bedrockhub

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import org.json.JSONArray
import org.json.JSONObject

const val BEDROCK_PKG = "com.mojang.minecraftpe"
const val GAME_PKG = "com.mastercraftnew.craftingbuilding"
val GAME_PKGS = setOf(BEDROCK_PKG, GAME_PKG)

class Cfg(
    var id: String,
    var label: String,
    var enabled: Boolean = true,
    var size: Int = 56,
    var alpha: Int = 80,
    var x: Int = 40,
    var y: Int = 300,
    var tx: Int = -1,
    var ty: Int = -1,
    var key: Int = 0
)

object Store {
    fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Cfg> {
        val raw = prefs(c).getString("buttons", null)
        val out = mutableListOf<Cfg>()
        if (raw != null) {
            try {
                val a = JSONArray(raw)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(
                        Cfg(
                            o.getString("id"), o.getString("label"), o.optBoolean("enabled", true),
                            o.optInt("size", 56), o.optInt("alpha", 80), o.optInt("x", 40), o.optInt("y", 300),
                            o.optInt("tx", -1), o.optInt("ty", -1), keyFor(o)
                        )
                    )
                }
            } catch (_: Exception) {
                out.clear()
            }
        }
        if (out.isNotEmpty() && !prefs(c).getBoolean("zoom_hold", false)) {
            out.firstOrNull { it.id == "zoom" && it.key == 31 }?.key = 1031
            prefs(c).edit().putBoolean("zoom_hold", true).apply()
            save(c, out)
        }
        if (out.isNotEmpty() && !prefs(c).getBoolean("zoom_added", false)) {
            if (out.none { it.id == "zoom" }) out.add(Cfg("zoom", "ZOOM", y = 750, key = 1031))
            prefs(c).edit().putBoolean("zoom_added", true).apply()
            save(c, out)
        }
        if (out.isEmpty()) {
            out.add(Cfg("q", "Q", y = 300, key = 45))
            out.add(Cfg("f5", "F5", y = 450, key = 135))
            out.add(Cfg("f1", "F1", y = 600, key = 131))
            out.add(Cfg("zoom", "ZOOM", y = 750, key = 1031))
            prefs(c).edit().putBoolean("zoom_added", true).apply()
        }
        return out
    }

    private fun keyFor(o: JSONObject): Int {
        if (o.has("key")) return o.optInt("key", 0)
        return when (o.getString("id")) {
            "q" -> 45
            "f5" -> 135
            "f1" -> 131
            else -> 0
        }
    }

    fun save(c: Context, list: List<Cfg>) {
        val a = JSONArray()
        for (b in list) {
            a.put(
                JSONObject().put("id", b.id).put("label", b.label).put("enabled", b.enabled)
                    .put("size", b.size).put("alpha", b.alpha).put("x", b.x).put("y", b.y)
                    .put("tx", b.tx).put("ty", b.ty).put("key", b.key)
            )
        }
        prefs(c).edit().putString("buttons", a.toString()).apply()
    }
}

val KEY_OPTIONS = listOf(
    "Ekranga bosish" to 0, "Q" to 45, "E" to 33, "R" to 46, "T" to 48, "F" to 34, "C" to 31, "C (bir bos: zoom, yana: normal)" to 1031, "G" to 35,
    "F1" to 131, "F2" to 132, "F3" to 133, "F4" to 134, "F5" to 135, "F6" to 136, "F11" to 141
)

object Keys {
    const val SHIZUKU_PKG = "moe.shizuku.privileged.api"

    /** 0: o'rnatilmagan, 1: ishga tushmagan, 2: ruxsat kerak, 3: tayyor */
    fun state(c: Context): Int {
        try {
            c.packageManager.getPackageInfo(SHIZUKU_PKG, 0)
        } catch (_: Exception) {
            return 0
        }
        return try {
            if (!Shizuku.pingBinder()) 1
            else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) 3
            else 2
        } catch (_: Throwable) {
            1
        }
    }

    fun requestPermission() {
        try { Shizuku.requestPermission(1001) } catch (_: Throwable) { }
    }

    private var proc: Process? = null
    private val held = HashSet<Int>()

    private fun newProcess(cmd: Array<String>): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, cmd, null, null) as Process
    }

    private fun tapKey(code: Int) {
        try { newProcess(arrayOf("input", "keyevent", code.toString())).waitFor() } catch (_: Throwable) { }
    }

    @Synchronized
    private fun helper(c: Context): Process {
        val cur = proc
        if (cur != null) {
            try {
                cur.exitValue()
            } catch (_: IllegalThreadStateException) {
                return cur
            }
        }
        val apk = c.applicationInfo.sourceDir
        val p = newProcess(
            arrayOf("sh", "-c", "CLASSPATH=$apk exec app_process /system/bin uz.example.bedrockhub.KeyHelper 2>/dev/null")
        )
        proc = p
        return p
    }

    private fun write(c: Context, line: String): Boolean {
        return try {
            val o = helper(c).outputStream
            o.write((line + "\n").toByteArray())
            o.flush()
            true
        } catch (_: Throwable) {
            proc = null
            false
        }
    }

    /** code >= 1000: birinchi bosish tugmani ushlab turadi, ikkinchisi qo'yib yuboradi. */
    fun send(c: Context, code: Int) {
        Thread {
            if (code >= 1000) {
                val k = code - 1000
                val on = !held.contains(k)
                if (write(c, (if (on) "down " else "up ") + k)) {
                    if (on) held.add(k) else held.remove(k)
                } else if (on) {
                    tapKey(k)
                }
            } else {
                tapKey(code)
            }
        }.start()
    }
}
